function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let confetes = [];

function setup() {
  createCanvas(800, 400);
  for (let i = 0; i < 120; i++) {
    confetes.push(new Confete());
  }
}

function draw() {
  background(135, 206, 235); // Céu azul claro

  drawCidade();
  drawCampo();

  for (let confete of confetes) {
    confete.update();
    confete.show();
  }

  drawPessoaFestejando();
}

// Pessoa no centro dançando
function drawPessoaFestejando() {
  push();
  translate(width / 2, height - 100);

  // Corpo
  fill(255, 180, 0);
  rectMode(CENTER);
  rect(0, 0, 40, 100);

  // Cabeça
  fill(255, 220, 180);
  ellipse(0, -70, 50);

  // Braços animados
  stroke(255, 180, 0);
  strokeWeight(8);
  let ang = sin(frameCount * 0.1) * PI / 4;
  line(-20, -30, -50 * cos(ang), -80 - 50 * sin(ang));
  line(20, -30, 50 * cos(ang), -80 - 50 * sin(ang));

  // Pernas
  line(-10, 50, -10, 80);
  line(10, 50, 10, 80);

  pop();
}

// Cidade do lado esquerdo
function drawCidade() {
  for (let i = 0; i < 5; i++) {
    let x = i * 60 + 20;
    let h = random(100, 200);
    fill(80);
    rect(x, height - h, 50, h);
    fill(255);
    for (let j = 0; j < 5; j++) {
      rect(x + 10, height - h + j * 30 + 10, 10, 10);
    }
  }
}

// Campo do lado direito
function drawCampo() {
  // Árvores
  for (let i = 0; i < 5; i++) {
    let x = width - i * 60 - 40;
    fill(101, 67, 33);
    rect(x, height - 60, 10, 40);
    fill(34, 139, 34);
    ellipse(x + 5, height - 70, 40);
  }

  // Sol
  fill(255, 204, 0);
  ellipse(width - 60, 60, 60);
}

class Confete {
  constructor() {
    this.x = random(width);
    this.y = random(-400, 0);
    this.speed = random(1, 3);
    this.size = random(4, 8);
    this.color = color(random(255), random(255), random(255));
  }

  update() {
    this.y += this.speed;
    if (this.y > height) {
      this.y = random(-100, 0);
      this.x = random(width);
    }
  }

  show() {
    noStroke();
    fill(this.color);
    ellipse(this.x, this.y, this.size);
  }
}
